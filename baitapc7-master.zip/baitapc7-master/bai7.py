import os
#tao thu muc.
os.mkdir('bai7')
#xem danh sach file
os.listdir()
#thay đổi tên
os.rename('bai7','thuc hanh6')
os.rename("thuc hanh7.txt","thuc hanh6.txt")
